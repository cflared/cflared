package ingress

import "github.com/cloudflare/cloudflared/logger"

var (
	TestLogger = logger.Create(nil)
)
