---
name: "\U0001F4DD Documentation"
about: Request new or updated documentation for cloudflared
title: "\U0001F4DD"
labels: 'Priority: Normal, Type: Documentation'

---

**Available Documentation**
A link to the documentation that is available today and the areas which could be improved. 

**Suggested Documentation**
A clear and concise description of the documentation, tutorial, or guide that should be added. 

**Additional context**
Add any other context or screenshots about the documentation request here.
